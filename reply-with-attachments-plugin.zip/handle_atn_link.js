/*
 * Module: handle_atn_link.js
 * Purpose: Open the ATN review page in a new tab when clicked.
 */
/* global RWA_LinkOpener */
RWA_LinkOpener.bindOnReady('atn-link');
