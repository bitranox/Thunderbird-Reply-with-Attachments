/*
 * Module: handle_docs_link.js
 * Purpose: Open the documentation site in a new tab when clicked.
 */
/* global RWA_LinkOpener */
RWA_LinkOpener.bindOnReady('docs-link');
