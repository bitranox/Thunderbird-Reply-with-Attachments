/*
 * Module: handle_donate_link.js
 * Purpose: Open the localized Donate link in a new tab when clicked.
 */
/* global RWA_LinkOpener */
RWA_LinkOpener.bindOnReady('donate-link');
